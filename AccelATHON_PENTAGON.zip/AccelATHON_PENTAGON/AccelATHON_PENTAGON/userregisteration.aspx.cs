﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.IO;

namespace AccelATHON_PENTAGON
{
    public partial class userregisteration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string m = "Male";
            string f = "Female";
            string o = "Unspecified";
            string query = "insert into ureg(fname,lname,gender,email,password,utype,contact,location)values(@fname,@lname,@gender,@email,@password,@utype,@contact,@location)";
            string connstr = "Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\Admin\\Documents\\Visual Studio 2010\\Projects\\AccelATHON_PENTAGON\\AccelATHON_PENTAGON\\App_Data\\Database1.mdf;Integrated Security=True;User Instance=True";
            try
            {
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.InsertCommand = new SqlCommand(query, conn);
                    da.InsertCommand.Parameters.Add("fname", SqlDbType.Text).Value = TextBox1.Text;
                    da.InsertCommand.Parameters.Add("lname", SqlDbType.Text).Value = TextBox2.Text;
                    if (RadioButton1.Checked == true)
                    {

                        da.InsertCommand.Parameters.Add("gender", SqlDbType.Text).Value = m;
                    }
                    else if (RadioButton2.Checked == true)
                    {
                        da.InsertCommand.Parameters.Add("gender", SqlDbType.Text).Value = f;
                    }
                    else if (RadioButton2.Checked == true)
                    {
                        da.InsertCommand.Parameters.Add("gender", SqlDbType.Text).Value = o;
                    }
                    da.InsertCommand.Parameters.Add("contact", SqlDbType.Text).Value = TextBox3.Text;
                    da.InsertCommand.Parameters.Add("email", SqlDbType.Text).Value = TextBox5.Text;
                    da.InsertCommand.Parameters.Add("location", SqlDbType.Text).Value = DropDownList2.Text;
                    da.InsertCommand.Parameters.Add("password", SqlDbType.Text).Value = TextBox6.Text;
                    da.InsertCommand.Parameters.Add("utype", SqlDbType.Text).Value = DropDownList1.Text;

                    conn.Open();
                    da.InsertCommand.ExecuteNonQuery();
                    conn.Close();
                    Response.Redirect("login.aspx");

                }
            }

            catch (SqlException ex)
            {
                Response.Write("Error occured" + ex.Message);
            }
        }

    }

        }
    
