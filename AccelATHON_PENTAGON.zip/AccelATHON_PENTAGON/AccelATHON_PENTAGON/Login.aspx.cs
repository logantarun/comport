﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.IO;
namespace AccelATHON_PENTAGON
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string query = "insert into ureg(fname,lname,gender,email,password,utype,contact,location)values(@fname,@lname,@gender,@email,@password,@utype,@contact,@location)";
            string connstr = "Data Source=.\\SQLEXPRESS;AttachDbFilename=C:\\Users\\Admin\\Documents\\Visual Studio 2010\\Projects\\AccelATHON_PENTAGON\\AccelATHON_PENTAGON\\App_Data\\Database1.mdf;Integrated Security=True;User Instance=True";
            try
            {
                using (SqlConnection conn = new SqlConnection(connstr))
                {
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = new SqlCommand("select * from ureg where email='" + TextBox3.Text + "' and password='" + TextBox4.Text + "'", conn);
                    conn.Open();
                    da.SelectCommand.ExecuteNonQuery();
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        SqlDataReader dataread = da.SelectCommand.ExecuteReader();
                        dataread.Read();
                        if (dataread.HasRows)
                        {
                            Session["fname"] = dataread[0].ToString();
                        }

                        Session["eid"] = TextBox3.Text;
                        TextBox3.Text = "";
                        TextBox3.Focus();
                        TextBox4.Text = "";
                        Response.Redirect("Homepage.aspx");
                    }
                    else
                    {
                        Label1.Visible = true;

                        Label1.Text = "Invalid username or password";
                        TextBox3.Text = "";
                        TextBox3.Focus();
                        TextBox4.Text = "";
                    }
                    conn.Close();
                }

            }

            catch (SqlException ex)
            {
                Response.Write("Error occured" + ex.Message);
            }


        }  
        
        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox3.Text = "";
            TextBox4.Text = "";
        }
    }
}